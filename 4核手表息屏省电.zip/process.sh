#!/system/bin/sh

dumpsys deviceidle enable


while true; do
    if [ "$(cat /sdcard/disable_cpu_status)" = "done" ]; then
        break
    fi
    if [ "$(cat /sdcard/disable_cpu_status)" = "powersafe" ]; then
        sleep 1
        echo 0 > /sys/devices/system/cpu/cpu1/online
        sleep 1
        echo 0 > /sys/devices/system/cpu/cpu2/online
        sleep 1
        echo 0 > /sys/devices/system/cpu/cpu3/online
        sleep 1
        dumpsys deviceidle force-idle
    else
        sleep 1
        echo 1 > /sys/devices/system/cpu/cpu1/online
        sleep 1
        echo 1 > /sys/devices/system/cpu/cpu2/online
        sleep 1
        echo 1 > /sys/devices/system/cpu/cpu3/online
    fi
    echo done > /sdcard/disable_cpu_status
    sleep 1
done