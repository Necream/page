PROPFILE=true
print_modname() {
  ui_print "*******************************"
  ui_print "     4核手表息屏省电 v2.0         "
  ui_print "       by Necream           "
  ui_print "*******************************"
  ui_print " 适用于4核手表，息屏时关闭CPU，达到省电效果"
  ui_print " 请注意，这需要你的系统sh支持jobs，否则会引起设备卡顿且无法正常使用，建议在安装前先确认系统sh支持jobs"
  ui_print " 你可以向Necream索要测试脚本来确认系统sh是否支持jobs"
}
on_install() {
  ui_print "- 正在安装..."
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}
set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644

}