#!/system/bin/sh

until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 3
done

CPU_ENABLE=-1
dumpsys deviceidle enable
touch /sdcard/disable_cpu_status
echo poweron > /sdcard/disable_cpu_status
sync_state() {
    BRIGHTNESS=$(cat /sys/class/backlight/sprd_backlight/brightness)
    if [ "$BRIGHTNESS" -ne "$CPU_ENABLE" ]; then
        if [ "$BRIGHTNESS" -eq 0 ]; then
            echo powersafe > /sdcard/disable_cpu_status
            # if [ "$(cat /sdcard/disable_cpu_running_flag)" -eq 0 ]; then
            #     ./process.sh &
            # fi
            if [ "$(jobs | grep process.sh)" ]; then
                :
            else
                sh "$(dirname "$0")/process.sh" &
            fi
        else
            echo poweron > /sdcard/disable_cpu_status
            if [ "$(jobs | grep process.sh)" ]; then
                :
            else
                sh "$(dirname "$0")/process.sh" &
            fi
        fi
        sleep 1
        CPU_ENABLE=$BRIGHTNESS
    fi
}

while true; do

    # Make sure the CPU state is correct during wait
    sync_state

    inotifywait -e modify /sys/class/backlight/sprd_backlight/brightness >/dev/null 2>&1

    BRIGHTNESS=$(cat /sys/class/backlight/sprd_backlight/brightness)
    if [ "$BRIGHTNESS" -eq 0 ]; then
        inotifywait -e modify /sys/class/backlight/sprd_backlight/brightness >/dev/null 2>&1 &
        sleep 5
        if jobs | grep -q "inotifywait"; then
            sync_state
        fi
        kill $(jobs -p) 2>/dev/null
    fi

done